//
// Created by matias on 12/05/17.
//

#ifndef CLIENT_CASILLAS_H
#define CLIENT_CASILLAS_H


/** REVIEW: Para qué esta clase? */
class Casillas {
private:
    int textura;

};


#endif //CLIENT_CASILLAS_H
