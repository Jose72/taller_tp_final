//
// Created by mbataglia on 23/05/17.
//

#ifndef Z_CLICKABLEBUTTONGRUNT_H
#define Z_CLICKABLEBUTTONGRUNT_H


#include "ClickableButton.h"
#include <string>
class ClickableButtonGrunt : public ClickableButton {
public:
	/** REVIEW: const std::string&. */
    ClickableButtonGrunt(int x, int y, int width, int height, std::string text,int idUnit);

    void click(Protocol aProtocol);
};


#endif //Z_CLICKABLEBUTTONGRUNT_H
