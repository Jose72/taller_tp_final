//
// Created by mbataglia on 12/06/17.
//

#include "InfoGameSelection.h"

InfoGameSelection::InfoGameSelection(int idCreator,
                                 int maxPlayers,
                                 int joinedPlayers,
                                 int typeGame,
                                 int numTeams):
        idCreator(idCreator),maxPlayers(maxPlayers),joinedPlayers(joinedPlayers), typeGame(typeGame), numTeams(numTeams){}

