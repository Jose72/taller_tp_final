
#ifndef CLIENT_T_CLIENT_H
#define CLIENT_T_CLIENT_H
//Se encarga de actualziar el mapa con unidades
//El serivdor envia codigo de unidad y posicion
//Agregar despues id de unidad
//Mapa de unidades
//Hilo para recibir y hilo para mandar
//Cliente envia id unidad posicion destino
//Mnadar id del mapa

/** REVIEW: Clase vacia. */
class T_Client {

};


#endif //CLIENT_T_CLIENT_H
