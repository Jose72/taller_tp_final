#ifndef BEHAVIOUR_H
#define BEHAVIOUR_H


/** REVIEW: Clase vacia. */
class behaviour {
	
};

#endif



