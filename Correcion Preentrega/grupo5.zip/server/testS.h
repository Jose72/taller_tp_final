#ifndef TESTS_CPP
#define TESTS_CPP

int test_create_units();
int test_info_players();
int test_unit_driving();
int flag_capture();
int test_death_of_target();
int test_bullet_attack();
int test_create_unit();
int test_auto_attack_unit();
int test_attack_unit_in_range();
int test_create_map();
int test_find_unit_tile();
int test_move_unit();
int test_units_in_range();

#endif