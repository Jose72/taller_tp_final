#include "terrain.h"
#include <iostream>

terrain::terrain(int terrain_code){
	switch(terrain_code){
		case(TIERRA):
			{
			this->construct(TIERRA, true, true, TIERRA_FACTOR);
			break;
			}
		case(PRADERA):
			{
			this->construct(PRADERA, true, true, PRADERA_FACTOR);
			break;
			}
		case(NIEVE):
			{
			this->construct(NIEVE, true, true, NIEVE_FACTOR);
			break;
			}
		case(AGUA):
			{
			this->construct(AGUA, true, false, AGUA_FACTOR);
			break;
			}
		case(PANTANO):
			{
			this->construct(PANTANO, true, false, PANTANO_FACTOR);
			break;
			}
		case(LAVA):
			{
			this->construct(LAVA, false, false, LAVA_FACTOR);
			break;
			}
		case(CARRETERA):
			{
			this->construct(CARRETERA, true, true, CARRETERA_FACTOR);
			break;
			}
		case(ASFALTO):
			{
			this->construct(ASFALTO, true, true, ASFALTO_FACTOR);
			break;
			}
		default:
			break;
	}
}

void terrain::construct(int t_type, bool pb_robot, bool pb_vehicle, double t_factor) {
	this->t_type = t_type;
	passable_by_robot = pb_robot;
	passable_by_vehicle = pb_vehicle;
	terrain_factor = t_factor;
}

terrain::terrain(int t_type, bool pb_robot, bool pb_vehicle, double t_factor): 
t_type(t_type), passable_by_robot(pb_robot), passable_by_vehicle(pb_vehicle), 
terrain_factor(t_factor) {}

bool terrain::isPassable(int unit_code){
	if (unit_code == ROBOT) return passable_by_robot;
	if (unit_code == VEHICLE) return passable_by_vehicle;
	return false;
}

double terrain::getTerrainFactor(){
	return terrain_factor;
}

int terrain::getTerrainCode(){
	return t_type;
}